import math

rr =  math.atan2(1,1)
print rr
pp = math.degrees(rr)
print pp
